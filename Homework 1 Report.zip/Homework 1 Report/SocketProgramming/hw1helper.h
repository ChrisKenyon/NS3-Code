#define NANO "129.10.33.163"
#define OHMS "129.10.33.164"
#define LAMINAR "129.10.33.161"
#define HERTZ "129.10.33.157"
#define PORT_ONE 30000
#define PORT_TWO 30150

#define CLIENT HERTZ
#define DESTINATION OHMS
#define SERVER NANO

#define useUDP 0
#define directEcho 0
